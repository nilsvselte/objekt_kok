package oving5;

interface Named {
    void setGivenName(String name);

    void setFamilyName(String name);

    void setFullName(String name);

    String getGivenName();

    String getFamilyName();

    String getFullName();
}
